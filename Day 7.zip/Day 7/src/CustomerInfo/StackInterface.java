package CustomerInfo;

public interface StackInterface {

	int stacksize=3;
	
	public void push(Customer c);
	
	public Customer pop();

}
