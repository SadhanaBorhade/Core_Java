package InterfaceTester;

import java.util.Scanner;

import CustomerInfo.*;

public class TestStack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ch=0;
		try(Scanner sc=new Scanner(System.in))
		{
			System.out.println("Enter the choice 1.FS 2.GS");
			ch=sc.nextInt();
			if(ch==1) {
			FixedStack fs=new FixedStack();
			Customer c[] = new Customer[StackInterface.stacksize];
			
			System.out.println("Enter Customer details");
			
			for(int i=0;i<StackInterface.stacksize;i++)
			{
				c[i]=new Customer(sc.nextInt(),sc.next(),sc.next());
				fs.push(c[i]);
			}
			
			for(int i=0;i<StackInterface.stacksize;i++)
			{
				c[i]=fs.pop();
				System.out.println(c[i]);
			}
			}
			else
			{
				GrowableStack gs=new GrowableStack();
				Customer c[] = new Customer[StackInterface.stacksize*2];
				
				System.out.println("Enter Customer details");
				for(int i=0;i<=c.length-1;i++)
				{
					c[i]=new Customer(sc.nextInt(),sc.next(),sc.next());
					gs.push(c[i]);
				}
				for(int i=0;i<=c.length-1;i++)
				{
					c[i]=gs.pop();
					System.out.println(c[i]);
				}
				
			}
		}
	}

}
